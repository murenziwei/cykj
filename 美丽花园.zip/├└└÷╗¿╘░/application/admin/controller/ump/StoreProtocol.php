<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\18 0018
 * Time: 10:45
 */

namespace app\admin\controller\ump;

use app\admin\model\store\StoreProtocol as ProtocolModel;
use app\admin\controller\AuthController;
use think\Url;
use service\JsonService as Json;
use think\Request;

class StoreProtocol extends AuthController
{
    public function edit_protocol(){
        $product = ProtocolModel::get(['type'=>1]);
//        if(!$product) return Json::fail('数据不存在!');
        $this->assign([
            'content'=>ProtocolModel::where('id',$product['id'])->value('description'),
            'field'=>'description',
            'action'=>Url::build('change_field',['id'=>$product['id'],'field'=>'description'])
        ]);
        return $this->fetch('public/edit_content');
    }

    public function change_field(Request $request,$id,$field){
        if(!$id) return $this->failed('数据不存在');
        $seckill = ProtocolModel::get($id);
        if(!$seckill) return Json::fail('数据不存在!');
        $data['description'] = $request->post('description');
        $res = ProtocolModel::edit($data,$id);
        if($res)
            return Json::successful('添加成功');
        else
            return Json::fail('添加失败');
    }
}