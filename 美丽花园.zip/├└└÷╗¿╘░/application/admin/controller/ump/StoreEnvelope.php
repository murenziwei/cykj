<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/4
 * Time: 14:31
 */

namespace app\admin\controller\ump;


use app\admin\controller\AuthController;
use service\UtilService as Util;
use service\FormBuilder as Form;
use service\JsonService as Json;
use think\Request;
use think\Url;
use app\admin\model\ump\StoreEnvelope as envelopeModel;

class StoreEnvelope extends AuthController
{
    /**
     * @return mixed
     */
    public function index()
    {
        $where = Util::getMore([
            ['status',''],
            ['title',''],
        ],$this->request);
        $this->assign('where',$where);
        $this->assign(envelopeModel::systemPage($where));
        return $this->fetch();
    }

    /**
     * @return mixed
     */
    public function create()
    {
        $f = array();
        $f[] = Form::input('title','红包名称');
        $f[] = Form::select('type','红包类型',1)->setOptions(function(){
            $menus = [['value'=>1,'label'=>'新人红包']];
            return $menus;
        })->filterable(1)->required('红包类型必选');
        $f[] = Form::number('envelope_price','红包面值',0)->min(0);
        $f[] = Form::number('sort','排序');
        $f[] = Form::radio('status','状态',0)->options([['label'=>'开启','value'=>1],['label'=>'关闭','value'=>0]]);

        $form = Form::make_post_form('添加红包',$f,Url::build('save'));
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }

    /**
     * @param Request $request
     * @return \think\response\Json
     */
    public function save(Request $request)
    {
        $data = Util::postMore([
            'title',
            'envelope_price',
            'sort',
            ['status',0]
        ],$request);
        if(!$data['title']) return Json::fail('请输入红包名称');
        if(!$data['envelope_price']) return Json::fail('请输入红包面值');
        $data['add_time'] = time();
        envelopeModel::set($data);
        return Json::successful('添加红包成功!');
    }

    /**
     * 显示编辑资源表单页.
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function edit($id)
    {
        $coupon = envelopeModel::get($id);
        if(!$coupon) return Json::fail('数据不存在!');
        $f = array();
        $f[] = Form::input('title','红包名称',$coupon->getData('title'));
        $f[] = Form::number('envelope_price','红包面值',$coupon->getData('envelope_price'))->min(0);
        $f[] = Form::number('sort','排序',$coupon->getData('sort'));
        $f[] = Form::radio('status','状态',$coupon->getData('status'))->options([['label'=>'开启','value'=>1],['label'=>'关闭','value'=>0]]);

        $form = Form::make_post_form('编辑红包',$f,Url::build('update',array('id'=>$id)));
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }


    /**
     * 保存更新的资源
     *
     * @param  \think\Request  $request
     * @param  int  $id
     * @return \think\Response
     */
    public function update(Request $request, $id)
    {
        $data = Util::postMore([
            'title',
            'envelope_price',
            'sort',
            ['status',0]
        ],$request);
        if(!$data['title']) return Json::fail('请输入红包名称');
        if(!$data['envelope_price']) return Json::fail('请输入红包面值');
        envelopeModel::edit($data,$id);
        return Json::successful('修改成功!');
    }

    /**
     * 删除指定资源
     *
     * @param  int  $id
     * @return \think\Response
     */
    public function delete($id)
    {
        if(!$id) return Json::fail('数据不存在!');
        $data['is_del'] = 1;
        if(!envelopeModel::edit($data,$id))
            return Json::fail(envelopeModel::getErrorInfo('删除失败,请稍候再试!'));
        else
            return Json::successful('删除成功!');
    }

    /**
     * 修改优惠券状态
     * @param $id
     * @return \think\response\Json
     */
    public function status($id)
    {
        if(!$id) return Json::fail('数据不存在!');
        if(!envelopeModel::editIsDel($id))
            return Json::fail(envelopeModel::getErrorInfo('修改失败,请稍候再试!'));
        else
            return Json::successful('修改成功!');
    }
}