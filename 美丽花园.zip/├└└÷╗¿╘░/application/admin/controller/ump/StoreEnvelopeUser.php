<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/4
 * Time: 16:36
 */

namespace app\admin\controller\ump;

use service\UtilService as Util;
use app\admin\controller\AuthController;
use app\admin\model\ump\StoreEnvelopeUser as EnvelopeUserModel;

class StoreEnvelopeUser extends AuthController
{
    /**
     * @return mixed
     */
    public function index()
    {
        $where = Util::getMore([
            ['status',''],
            ['is_fail',''],
            ['envelope_title',''],
            ['nickname',''],
        ],$this->request);
        $this->assign('where',$where);
        $this->assign(EnvelopeUserModel::systemPage($where));
        return $this->fetch();
    }
}