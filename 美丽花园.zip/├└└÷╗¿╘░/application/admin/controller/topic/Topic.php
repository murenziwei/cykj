<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\9 0009
 * Time: 10:15
 */

namespace app\admin\controller\topic;

use app\admin\controller\AuthController;
use service\UtilService as Util;
use service\PHPTreeService as Phptree;
use service\JsonService as Json;
use service\UploadService as Upload;
use think\Request;
use think\Url;
use app\admin\model\topic\Topic as TopicModel;
use app\admin\model\topic\StoreTopic as StoreTopicModel;
use service\FormBuilder as Form;
use app\admin\model\store\StoreProduct as ProductModel;

class Topic extends AuthController
{
    /**
     * 显示后台管理员添加的图文
     * @return mixed
     */
    public function index()
    {
        $where = Util::getMore([
            ['title', ''],
            ['status', '']
        ], $this->request);
        $this->assign('where', $where);
        $this->assign(TopicModel::getAll($where));
        return $this->fetch();
    }

    public function edit($id){
        if(!$id) return $this->failed('数据不存在');
        $topicInfo = TopicModel::get(['tid'=>$id]);
        $f = array();
        $f[] = Form::radio('status', '帖子状态', $topicInfo->getData('status'))->options([['label' => '显示', 'value' => 1], ['label' => '屏蔽', 'value' => 0]])->col(8);
        $form = Form::make_post_form('编辑帖子', $f,Url::build('update',array('id'=>$id)),2);
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }

    /**
     * 更新
     * @param Request $request
     * @param $id
     */
    public function update(Request $request, $id){
        $data = Util::postMore([
            ['status', 0],
        ], $request);
        if(!$id) return $this->failed('数据不存在');
        if (!TopicModel::edit($data,$id)) return Json::fail('帖子列表更新失败');
        return Json::successful('更新帖子成功!');
    }

    /**
     * 删除图文
     * @param $id
     * @return \think\response\Json
     */
    public function delete($id)
    {
        $res = TopicModel::del($id);
        if (!$res)
            return Json::fail('删除失败,请稍候再试!');
        else
            return Json::successful('删除成功!');
    }

    public function merchantIndex()
    {
        $where = Util::getMore([
            ['title', '']
        ], $this->request);
        $this->assign('where', $where);
        $where['cate_id'] = input('cate_id');
        $where['merchant'] = 1;//区分是管理员添加的图文显示  0 还是 商户添加的图文显示  1
        $this->assign(StoreTopicModel::getAll($where));
        return $this->fetch();
    }
}