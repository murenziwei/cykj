<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\9 0009
 * Time: 16:49
 */

namespace app\admin\controller\topic;

use app\admin\controller\AuthController;
use service\UtilService as Util;
use service\JsonService as Json;
use service\FormBuilder as Form;
use think\Url;
use think\Request;
use app\admin\model\topic\TopicReply as TopicReplyModel;

class TopicReply extends AuthController
{
    public function index($reply_type,$topic_id){
        $where = Util::getMore([
            ['comment', ''],
            ['status', ''],
        ], $this->request);
        $where['reply_type'] = $reply_type;
        $where['topic_id'] = $topic_id;
        $this->assign('where', $where);
        $this->assign(TopicReplyModel::getAll($where));
        return $this->fetch();
    }

    public function edit($id){
        if(!$id) return $this->failed('数据不存在');
        $topicReplyInfo = TopicReplyModel::get(['id'=>$id]);
        $f = array();
        $f[] = Form::radio('status', '评论状态', $topicReplyInfo->getData('status'))->options([['label' => '显示', 'value' => 1], ['label' => '屏蔽', 'value' => 0]])->col(8);
        $form = Form::make_post_form('修改状态', $f,Url::build('update',array('id'=>$id)),2);
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }

    public function update(Request $request, $id){
        $data = Util::postMore([
            ['status', 0],
            ['is_del', 0],
        ], $request);
        if(!$id) return $this->failed('数据不存在');
        if (!TopicReplyModel::edit($data,$id)) return Json::fail('状态更新失败');
        return Json::successful('更新状态成功!');
    }
}