<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\9 0009
 * Time: 10:15
 */

namespace app\admin\controller\topic;

use app\admin\controller\AuthController;
use service\UtilService as Util;
use service\PHPTreeService as Phptree;
use service\JsonService as Json;
use service\UploadService as Upload;
use think\Request;
use think\Url;
use app\admin\model\topic\TopicCategory as TopicCategoryModel;
use app\admin\model\topic\StoreTopic as StoreTopicModel;
use service\FormBuilder as Form;
use app\admin\model\store\StoreProduct as ProductModel;

class StoreTopic extends AuthController
{
    /**
     * 显示后台管理员添加的图文
     * @return mixed
     */
    public function index($pid = 0)
    {
        $where = Util::getMore([
            ['title', ''],
            ['cate_id', '']
        ], $this->request);
        $pid = $this->request->param('pid');
        $this->assign('where', $where);
        $where['merchant'] = 0;//区分是管理员添加的图文显示  0 还是 商户添加的图文显示  1
        $catlist = TopicCategoryModel::where('is_del', 0)->select()->toArray();
        //获取分类列表
        if ($catlist) {
            $tree = Phptree::makeTreeForHtml($catlist);
            $this->assign(compact('tree'));
            if ($pid) {
                $pids = Util::getChildrenPid($tree, $pid);
                $where['cate_id'] = ltrim($pid . $pids);
            }
        } else {
            $tree = [];
            $this->assign(compact('tree'));
        }
        $this->assign('cate', TopicCategoryModel::getTierList());
        $this->assign(StoreTopicModel::getAll($where));
        return $this->fetch();
    }

    /**
     * 展示页面   添加和删除
     * @return mixed
     */
    public function create()
    {
        $f = array();
        $f[] = Form::input('title', '帖子标题')->required('帖子标题');
        $f[] = Form::select('cate_id', '所属专题')->setOptions(function () {
            $list = TopicCategoryModel::getTierList();
//            $menus[] = ['value'=>0,'label'=>'顶级分类'];
            foreach ($list as $menu) {
                $menus[] = ['value' => $menu['id'], 'label' => $menu['html'] . $menu['title']];
            }
            return $menus;
        })->filterable(1)->required('请选择专题');
        $f[] = Form::select('goods_id', '关联商品', 2)->setOptions(function () {
            $list = ProductModel::where(['is_show' => 1, 'is_del' => 0])->field('id,store_name,image')->select()->toArray() ?: [];
            foreach ($list as $menu) {
                $menus[] = ['value' => $menu['id'], 'label' => $menu['store_name']];
            }
            return $menus;
        })->filterable(1)->multiple(1)->required('请选择商品');
        $f[] = Form::radio('layout', '图片布局', 1)->options([['label' => '大图', 'value' => 1], ['label' => '小图', 'value' => 2], ['label' => '多图', 'value' => 3]]);
        $f[] = Form::number('sort', '排序')->col(8);
        $f[] = Form::input('content', '内容', '', 'textarea')->rows(10);
        $f[] = Form::radio('status', '帖子状态', 1)->options([['label' => '上架', 'value' => 1], ['label' => '下架', 'value' => 0]])->col(8);
        $form = Form::make_post_form('添加帖子', $f, Url::build('save'));
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }

    /**
     * 保存添加
     * @param Request $request
     */
    public function save(Request $request)
    {
        $data = Util::postMore([
            'title',
            ['cate_id', []],
            ['goods_id', []],
            ['content',],
            ['layout', 1],
            ['sort', 0],
            ['status', 1],
        ], $request);
        if (count($data['cate_id']) < 1) return Json::fail('请选择专题分类');
        $data['cate_id'] = implode(',', $data['cate_id']);
        if (!$data['title']) return Json::fail('请输入帖子标题');
        if (count($data['goods_id']) < 1) return Json::fail('请选择关联商品');
        $params = [];
        foreach ($data['goods_id'] as $k => $val) {
            $goodsInfo = ProductModel::where('id', $val)->field('id,image,slider_image')->find();
            if ($goodsInfo) {
                $params[] = [
                    'images' => $goodsInfo['image'],
                    'goods_id' => $val,
                ];
            }
        }
        $data['params'] = $params;
        $data['add_time'] = time();
        unset($data['goods_id']);
        if (!$data['content']) return Json::fail('请输入帖子内容');
        if (!StoreTopicModel::set($data)) return Json::fail('帖子列表添加失败');
        return Json::successful('添加帖子成功!');
    }

    public function edit($id){
        if(!$id) return $this->failed('数据不存在');
        $topicInfo = StoreTopicModel::get(['tid'=>$id]);
        $f = array();
        $f[] = Form::input('title', '帖子标题',$topicInfo['title'])->required('帖子标题');
        $f[] = Form::select('cate_id', '所属专题',[$topicInfo['cate_id']])->setOptions(function () {
            $list = TopicCategoryModel::getTierList();
//            $menus[] = ['value'=>0,'label'=>'顶级分类'];
            $menus=[];
            foreach ($list as $menu) {
                $menus[] = ['value' => $menu['id'], 'label' => $menu['html'] . $menu['title']];
            }
            return $menus;
        })->filterable(1)->multiple(0)->required('请选择专题');
        $goods_ids = array_column($topicInfo['params'],'goods_id');
        $f[] = Form::select('goods_id', '关联商品',$goods_ids)->setOptions(function () {
            $list = ProductModel::where(['is_show' => 1, 'is_del' => 0])->field('id,store_name,image')->select()->toArray() ?: [];
            $menus=[];
            foreach ($list as $menu) {
                $menus[] = ['value' => $menu['id'], 'label' => $menu['store_name']];
            }
            return $menus;
        })->filterable(1)->multiple(1)->required('请选择商品');
        $f[] = Form::radio('layout', '图片布局', $topicInfo->getData('layout'))->options([['label' => '大图', 'value' => 1], ['label' => '小图', 'value' => 2], ['label' => '多图', 'value' => 3]]);
        $f[] = Form::number('sort', '排序', $topicInfo->getData('sort'))->col(8);
        $f[] = Form::input('content', '内容',  $topicInfo['content'], 'textarea')->rows(10);
        $f[] = Form::radio('status', '帖子状态', $topicInfo->getData('status'))->options([['label' => '上架', 'value' => 1], ['label' => '下架', 'value' => 0]])->col(8);
        $form = Form::make_post_form('添加帖子', $f,Url::build('update',array('id'=>$id)),2);
        $this->assign(compact('form'));
        return $this->fetch('public/form-builder');
    }

    /**
     * 更新
     * @param Request $request
     * @param $id
     */
    public function update(Request $request, $id){
        $data = Util::postMore([
            'title',
            ['cate_id', []],
            ['goods_id', []],
            ['content',],
            ['layout', 1],
            ['sort', 0],
            ['status', 1],
        ], $request);
        if (count($data['cate_id']) < 1) return Json::fail('请选择专题分类');
        $data['cate_id'] = implode(',', $data['cate_id']);
        if (!$data['title']) return Json::fail('请输入帖子标题');
        if (count($data['goods_id']) < 1) return Json::fail('请选择关联商品');
        $params = [];
        foreach ($data['goods_id'] as $k => $val) {
            $goodsInfo = ProductModel::where('id', $val)->field('id,image,slider_image')->find();
            if ($goodsInfo) {
                $params[] = [
                    'images' => $goodsInfo['image'],
                    'goods_id' => $val,
                ];
            }
        }
        $data['params'] = $params;
        unset($data['goods_id']);
        if (!$data['content']) return Json::fail('请输入帖子内容');
        if (!StoreTopicModel::edit($data,$id)) return Json::fail('帖子列表更新失败');
        return Json::successful('更新帖子成功!');
    }

    /**
     * 上传图文图片
     * @return \think\response\Json
     */
    public function upload_image()
    {
        $res = Upload::Image($_POST['file'], 'wechat/image/' . date('Ymd'));
        //产品图片上传记录
        $fileInfo = $res->fileInfo->getinfo();
        SystemAttachment::attachmentAdd($res->fileInfo->getSaveName(), $fileInfo['size'], $fileInfo['type'], $res->dir, '', 5);
        if (!$res->status) return Json::fail($res->error);
        return Json::successful('上传成功!', ['url' => $res->filePath]);
    }

    /**
     * 添加和修改图文
     * @param Request $request
     * @return \think\response\Json
     */
    public function add_new(Request $request)
    {
        $post = $request->post();
        $data = Util::postMore([
            ['id', 0],
            ['cid', []],
            'title',
            'author',
            'image_input',
            'content',
            'synopsis',
            'share_title',
            'share_synopsis',
            ['visit', 0],
            ['sort', 0],
            'url',
            ['is_banner', 0],
            ['is_hot', 0],
            ['status', 1],], $request);
        $data['cid'] = implode(',', $data['cid']);
        $content = $data['content'];
        unset($data['content']);
        if ($data['id']) {
            $id = $data['id'];
            unset($data['id']);
            ArticleModel::beginTrans();
            $res1 = ArticleModel::edit($data, $id, 'id');
            $res2 = ArticleModel::setContent($id, $content);
            if ($res1 && $res2)
                $res = true;
            else
                $res = false;
//            dump($res);
//            exit();
            ArticleModel::checkTrans($res);
            if ($res)
                return Json::successful('修改图文成功!', $id);
            else
                return Json::fail('修改图文失败!', $id);
        } else {
            $data['add_time'] = time();
            $data['admin_id'] = $this->adminId;
            ArticleModel::beginTrans();
            $res1 = ArticleModel::set($data);
            $res2 = false;
            if ($res1)
                $res2 = ArticleModel::setContent($res1->id, $content);
            if ($res1 && $res2)
                $res = true;
            else
                $res = false;
            ArticleModel::checkTrans($res);
            if ($res)
                return Json::successful('添加图文成功!', $res1->id);
            else
                return Json::successful('添加图文失败!', $res1->id);
        }
    }

    /**
     * 删除图文
     * @param $id
     * @return \think\response\Json
     */
    public function delete($id)
    {
        $res = StoreTopicModel::del($id);
        if (!$res)
            return Json::fail('删除失败,请稍候再试!');
        else
            return Json::successful('删除成功!');
    }

    public function merchantIndex()
    {
        $where = Util::getMore([
            ['title', '']
        ], $this->request);
        $this->assign('where', $where);
        $where['cate_id'] = input('cate_id');
        $where['merchant'] = 1;//区分是管理员添加的图文显示  0 还是 商户添加的图文显示  1
        $this->assign(StoreTopicModel::getAll($where));
        return $this->fetch();
    }
}