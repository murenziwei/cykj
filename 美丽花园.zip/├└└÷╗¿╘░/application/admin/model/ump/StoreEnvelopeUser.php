<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/4
 * Time: 16:38
 */

namespace app\admin\model\ump;


use basic\ModelBasic;
use traits\ModelTrait;
use app\admin\model\wechat\WechatUser as UserModel;


class StoreEnvelopeUser extends ModelBasic
{
    use ModelTrait;

    /**
     * @param $where
     * @return array
     */
    public static function systemPage($where){
        $model = new self;
        if($where['status'] != '')  $model = $model->where('status',$where['status']);
        if($where['is_fail'] != '')  $model = $model->where('status',$where['is_fail']);
        if($where['envelope_title'] != '')  $model = $model->where('envelope_title','LIKE',"%$where[envelope_title]%");
        if($where['nickname'] != ''){
            $uid = UserModel::where('nickname','LIKE',"%$where[nickname]%")->column('uid');
            $model = $model->where('uid','IN',implode(',',$uid));
        };
//        $model = $model->where('is_del',0);
        $model = $model->order('id desc');
        return self::page($model,function ($item){
            $item['nickname'] = UserModel::where('uid',$item['uid'])->value('nickname');
        },$where);
    }
}