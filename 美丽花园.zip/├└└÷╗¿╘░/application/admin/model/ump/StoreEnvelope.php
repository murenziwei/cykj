<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/4
 * Time: 14:45
 */

namespace app\admin\model\ump;

use basic\ModelBasic;
use traits\ModelTrait;

class StoreEnvelope extends ModelBasic
{
    use ModelTrait;

    /**
     * @param $where
     * @return array
     */
    public static function systemPage($where){
        $model = new self;
        if($where['status'] != '')  $model = $model->where('status',$where['status']);
        if($where['title'] != '')  $model = $model->where('title','LIKE',"%$where[title]%");
//        if($where['is_del'] != '')  $model = $model->where('is_del',$where['is_del']);
        $model = $model->where('is_del',0);
        $model = $model->order('sort desc,id desc');
        return self::page($model,$where);
    }

    public function editIsDel($id){
        $data['status'] = 0;
        self::beginTrans();
        $res1 = self::edit($data,$id);
        $res  = $res1;
        self::checkTrans($res);
        return $res;
    }
}