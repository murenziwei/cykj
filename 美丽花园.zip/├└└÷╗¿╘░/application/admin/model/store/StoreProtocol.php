<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\18 0018
 * Time: 10:17
 */

namespace app\admin\model\store;
use basic\ModelBasic;
use traits\ModelTrait;

class StoreProtocol extends ModelBasic
{
    use ModelTrait;
}