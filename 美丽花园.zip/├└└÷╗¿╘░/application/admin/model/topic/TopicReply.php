<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\9 0009
 * Time: 16:50
 */

namespace app\admin\model\topic;

use think\Db;
use basic\ModelBasic;
use traits\ModelTrait;

class TopicReply extends ModelBasic
{
    use ModelTrait;

    /**
     * 获取评论列表
     * @param array $where
     * @return array
     */
    public static function getAll($where = array()){
        $model = new self;
        if($where['status'] !== '') $model = $model->where('status',$where['status']);
        if($where['reply_type'] !== '') $model = $model->where('reply_type',strtolower($where['reply_type']));
        if($where['topic_id'] !== '') $model = $model->where('topic_id',$where['topic_id']);
        if($where['status'] !== '') $model = $model->where('status',$where['status']);
        if($where['comment'] !== '') $model = $model->where('comment','LIKE',"%$where[comment]%");
        $model = $model->where('is_del',0);//var_dump($where);exit;
        return self::page($model,function($item){
            $userInfo = Db::name('User')->where('uid',$item['uid'])->field('uid,avatar,nickname')->find();
            $item['nickname'] = isset($userInfo['nickname'])?$userInfo['nickname']:'';
            $item['avatar'] = isset($userInfo['avatar'])?$userInfo['avatar']:'';
        },$where);
    }


}