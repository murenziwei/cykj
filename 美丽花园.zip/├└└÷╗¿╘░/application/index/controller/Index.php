<?php
namespace app\index\controller;

class Index
{
    public function _empty()
    {
//        header('Location:http://www.crmeb.net/');
        exit;
    }
}


