<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/4
 * Time: 17:16
 */

namespace app\routine\model\user;

use basic\ModelBasic;
use traits\ModelTrait;

class EnvelopeUser extends ModelBasic
{
    use ModelTrait;

    protected $insert = ['add_time'];

    protected function setAddTimeAttr()
    {
        return time();
    }

    public static function income($envelope_title,$uid,$type,$envelope_price,$eid = 0,$mark = '',$status = 1)
    {
        return self::set(compact('envelope_title','uid','eid','type','envelope_price','mark','status'));
    }

    public static function expend($title,$uid,$category,$type,$number,$link_id = 0,$balance = 0,$mark = '',$status = 1)
    {
        $pm = 0;
        return self::set(compact('title','uid','link_id','category','type','number','balance','mark','status','pm'));
    }

}