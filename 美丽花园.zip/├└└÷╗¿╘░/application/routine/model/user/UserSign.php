<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2018/02/28
 */

namespace app\routine\model\user;


use basic\ModelBasic;
use service\SystemConfigService;
use think\Model;

class UserSign
{
    public static function checkUserSigned($uid,$type=1)
    {
        return UserBill::be(['uid'=>$uid,'add_time'=>['>=',strtotime('today')],'category'=>'integral','type'=>'sign','bill_type'=>$type]);
    }

    public static function userSignedCount($uid)
    {
        return self::userSignBillWhere($uid)->count();
    }

    /**
     * @param $uid
     * @return Model
     */
    public static function userSignBillWhere($uid)
    {
        return UserBill::where(['uid'=>$uid,'category'=>'integral','type'=>'sign']);
    }

    public static function sign($userInfo,$type)
    {
        $uid = $userInfo['uid'];
        $wuserInfo = WechatUser::get(['uid'=>$uid]);
        $time = strtotime(date('Y-m-d 23:59:59',time()));
        if($type==1){//商城
            $min = SystemConfigService::get('shop_sign_min_int')?:0;
            $max = SystemConfigService::get('shop_sign_max_int')?:5;
            if(($wuserInfo['shop_sign']+1)>7){
                $integral = $max;
            }else{
                $integral = $min;
            }
            $field = 'shop_sign';
            $field_time = 'shop_sign_time';
        }else{//社区
            $min = SystemConfigService::get('topic_sign_min_int')?:0;
            $max = SystemConfigService::get('topic_sign_max_int')?:5;
            if(($wuserInfo['topic_sign']+1)>7){
                $integral = $max;
            }else{
                $integral = $min;
            }
            $field = 'topic_sign';
            $field_time = 'topic_sign_time';
        }
        //赠送积分
        $total_integral = (SystemConfigService::get('total_integral') ?: 0);
        $use_total_integral = (UserBill::where('category','integral')->where('status',1)->sum('number') ?: 0);
        $remain_integral = bcsub($total_integral,$use_total_integral);
        if($remain_integral==0){
            return 0;
        }
        if($remain_integral<$integral){
            $integral = $remain_integral;
        }
        ModelBasic::beginTrans();
        $res1 = UserBill::income('用户签到',$uid,'integral','sign',$integral,0,$userInfo['integral'],'签到获得'.floatval($integral).'积分',1,$type);
        $res2 = User::bcInc($uid,'integral',$integral,'uid');
        WechatUser::bcInc($uid,$field,1,'uid');
        WechatUser::edit([$field_time=>$time],$uid);
        $res = $res1 && $res2;
        ModelBasic::checkTrans($res);
        if($res)
            return $integral;
        else
            return false;
    }
}