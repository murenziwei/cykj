<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/12/21
 */

namespace app\routine\model\user;

use app\routine\model\store\StoreEnvelopeUser;
use app\routine\model\store\StoreOrder;
use basic\ModelBasic;
use service\SystemConfigService;
use think\Request;
use think\Session;
use traits\ModelTrait;

/**
 * 用户model
 * Class User
 * @package app\routine\model\user
 */
class User extends ModelBasic
{
    use ModelTrait;

    public static function updateWechatUser($wechatUser,$uid)
    {
        return self::edit([
            'nickname'=>$wechatUser['nickname']?:'',
            'avatar'=>$wechatUser['headimgurl']?:'',
            'last_time'=>time(),
            'last_ip'=>Request::instance()->ip(),
        ],$uid,'uid');
    }



    /**
     * 小程序用户添加
     * @param $routineUser
     * @param int $spread_uid
     * @return object
     */
    public static function setRoutineUser($routineUser,$spread_uid = 0){
        return self::set([
            'account'=>'rt'.$routineUser['uid'].time(),
            'pwd'=>md5(123456),
            'nickname'=>$routineUser['nickname']?:'',
            'avatar'=>$routineUser['headimgurl']?:'',
            'spread_uid'=>$spread_uid,
            'uid'=>$routineUser['uid'],
            'add_time'=>$routineUser['add_time'],
            'add_ip'=>Request::instance()->ip(),
            'last_time'=>time(),
            'last_ip'=>Request::instance()->ip(),
            'user_type'=>$routineUser['user_type'],
            'track_pid_list'=>$routineUser['track_pid_list'],
            'is_promoter'=>1,
        ]);
    }

    /**
     * 获得当前登陆用户UID
     * @return int $uid
     */
    public static function getActiveUid()
    {
        $uid = null;
        $uid = Session::get('LoginUid');
        if($uid) return $uid;
        else return 0;
    }
    public static function getUserInfo($uid)
    {
        $userInfo = self::where('uid',$uid)->find();
        if(!$userInfo) exception('读取用户信息失败!');
        return $userInfo->toArray();
    }

    /**
     * 判断当前用户是否推广员
     * @param int $uid
     * @return bool
     */
    public static function isUserSpread($uid = 0){
        if(!$uid) return false;
        $status = (int)SystemConfigService::get('store_brokerage_statu');
        $isPromoter = true;
        if($status == 1) $isPromoter = self::where('uid',$uid)->value('is_promoter');
        if($isPromoter) return true;
        else return false;
    }


    /**
     * 小程序用户一级分销（支付后记录，收货后分佣）
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerage($orderInfo)
    {
        $userInfo = User::getUserInfo($orderInfo['uid']);
        if(!$userInfo || !$userInfo['spread_uid']) return true;
        $storeBrokerageStatu = SystemConfigService::get('store_brokerage_statu') ? : 1;//获取后台分销类型
        if($storeBrokerageStatu == 1){
            if(!User::be(['uid'=>$userInfo['spread_uid'],'is_promoter'=>1])) return true;
        }
        $brokerageRatio = (SystemConfigService::get('store_brokerage_ratio') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $cost = isset($orderInfo['cost']) ? $orderInfo['cost'] : 0;//成本价
//        if($cost > $orderInfo['pay_price']) return true;//成本价大于支付价格时直接返回
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
//        $brokeragePrice = bcmul(bcsub($orderInfo['pay_price'],$cost,2),$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = $userInfo['nickname'].'成功消费'.floatval($orderInfo['pay_price']).'元,奖励推广佣金'.floatval($brokeragePrice);
        self::beginTrans();
        $res1 = UserBill::income('获得推广佣金',$userInfo['spread_uid'],'now_money','brokerage',$brokeragePrice,$orderInfo['id'],0,$mark,0,2);
//        $res2 = self::bcInc($userInfo['spread_uid'],'now_money',$brokeragePrice,'uid');
//        $res = $res1 && $res2;
        $res = $res1;
        self::checkTrans($res);
        if($res) self::backOrderBrokerageTwo($orderInfo);
        return $res;
    }

    /**
     * 小程序 二级推广（支付后记录，收货后分佣）
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerageTwo($orderInfo){
        $userInfo = User::getUserInfo($orderInfo['uid']);
        $userInfoTwo = User::getUserInfo($userInfo['spread_uid']);
        if(!$userInfoTwo || !$userInfoTwo['spread_uid']) return true;
        $storeBrokerageStatu = SystemConfigService::get('store_brokerage_statu') ? : 1;//获取后台分销类型
        if($storeBrokerageStatu == 1){
            if(!User::be(['uid'=>$userInfoTwo['spread_uid'],'is_promoter'=>1]))  return true;
        }
        $brokerageRatio = (SystemConfigService::get('store_brokerage_two') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $cost = isset($orderInfo['cost']) ? $orderInfo['cost'] : 0;//成本价
//        if($cost > $orderInfo['pay_price']) return true;//成本价大于支付价格时直接返回
//        $brokeragePrice = bcmul(bcsub($orderInfo['pay_price'],$cost,2),$brokerageRatio,2);
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = '二级推广人'.$userInfo['nickname'].'成功消费'.floatval($orderInfo['pay_price']).'元,奖励推广佣金'.floatval($brokeragePrice);
        self::beginTrans();
        $res1 = UserBill::income('获得推广佣金',$userInfoTwo['spread_uid'],'now_money','brokerage',$brokeragePrice,$orderInfo['id'],0,$mark,0,2);
//        $res2 = self::bcInc($userInfoTwo['spread_uid'],'now_money',$brokeragePrice,'uid');
//        $res = $res1 && $res2;
        $res = $res1;
        self::checkTrans($res);
        if($res) self::backOrderBrokerageThree($orderInfo);
        return $res;
    }

    /**
     * 小程序 三级推广（支付后记录，收货后分佣）
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerageThree($orderInfo){
        $userInfo = User::getUserInfo($orderInfo['uid']);
        $userInfoTwo = User::getUserInfo($userInfo['spread_uid']);
        $userInfoThree = User::getUserInfo($userInfoTwo['spread_uid']);
        if(!$userInfoThree || !$userInfoThree['spread_uid']) return true;
        $storeBrokerageStatu = SystemConfigService::get('store_brokerage_statu') ? : 1;//获取后台分销类型
        if($storeBrokerageStatu == 1){
            if(!User::be(['uid'=>$userInfoThree['spread_uid'],'is_promoter'=>1]))  return true;
        }
        $brokerageRatio = (SystemConfigService::get('store_brokerage_two') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $cost = isset($orderInfo['cost']) ? $orderInfo['cost'] : 0;//成本价
//        if($cost > $orderInfo['pay_price']) return true;//成本价大于支付价格时直接返回
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
//        $brokeragePrice = bcmul(bcsub($orderInfo['pay_price'],$cost,2),$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = '三级推广人'.$userInfo['nickname'].'成功消费'.floatval($orderInfo['pay_price']).'元,奖励推广佣金'.floatval($brokeragePrice);
        self::beginTrans();
        $res1 = UserBill::income('获得推广佣金',$userInfoThree['spread_uid'],'now_money','brokerage',$brokeragePrice,$orderInfo['id'],0,$mark,0,2);
//        $res2 = self::bcInc($userInfoThree['spread_uid'],'now_money',$brokeragePrice,'uid');
//        $res = $res1 && $res2;
        $res = $res1;
        self::checkTrans($res);
        return $res;
    }

    /**
     * 小程序区域代理无限代分销
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerageUnlimited($orderInfo){
        $userInfo = User::getUserInfo($orderInfo['uid']);
        $track_pid_list = User::where('uid',$orderInfo['uid'])->value('track_pid_list');
        if($track_pid_list=='0') return true;
        $track_pid_list_arr = explode('-',$track_pid_list);
        $top_uid = $track_pid_list_arr[1];
        $user_identity = User::where('uid',$top_uid)->value('user_identity');
        if($user_identity==0) return true;
        $brokerageRatio = (SystemConfigService::get('store_brokerage_unlimited') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $cost = isset($orderInfo['cost']) ? $orderInfo['cost'] : 0;//成本价
//        if($cost > $orderInfo['pay_price']) return true;//成本价大于支付价格时直接返回
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
//        $brokeragePrice = bcmul(bcsub($orderInfo['pay_price'],$cost,2),$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = '下级推广人'.$userInfo['nickname'].'成功消费'.floatval($orderInfo['pay_price']).'元,奖励代理推广佣金'.floatval($brokeragePrice);
        self::beginTrans();
        $res1 = UserBill::income('获得代理推广佣金',$top_uid,'now_money','brokerage',$brokeragePrice,$orderInfo['id'],0,$mark,0,1);
//        $res2 = self::bcInc($top_uid,'now_money',$brokeragePrice,'uid');
//        $res = $res1 && $res2;
        $res = $res1;
        self::checkTrans($res);
        return $res;
    }

    /**
     * 小程序用户自购返利
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerageRebate($orderInfo){
        $brokerageRatio = (SystemConfigService::get('store_rebate_ratio') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $cost = isset($orderInfo['cost']) ? $orderInfo['cost'] : 0;//成本价
//        if($cost > $orderInfo['pay_price']) return true;//成本价大于支付价格时直接返回
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
//        $brokeragePrice = bcmul(bcsub($orderInfo['pay_price'],$cost,2),$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = '成功消费'.floatval($orderInfo['pay_price']).'元,奖励自购佣金'.floatval($brokeragePrice);
        self::beginTrans();
        $res1 = UserBill::income('获得自购佣金',$orderInfo['uid'],'now_money','brokerage',$brokeragePrice,$orderInfo['id'],0,$mark,0,2);
//        $res2 = self::bcInc($orderInfo['uid'],'now_money',$brokeragePrice,'uid');
//        $res = $res1 && $res2;
        $res = $res1;
        self::checkTrans($res);
        return $res;
    }

    /**
     * 收货后正式返佣
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderBrokerageTrue($orderInfo){
        $list = UserBill::where('link_id',$orderInfo['id'])->where('category','now_money')->where('type','brokerage')
            ->where('pm',1)->where('status',0)->field('id,uid,link_id,number')->select();
        if(empty($list)) return true;
        self::beginTrans();
        $res = true;
        foreach ($list as $k => $val){
            $res1 = self::bcInc($val['uid'],'now_money',$val['number'],'uid');
            $res2 = UserBill::edit(['status'=>1],$val['id']);
            $res = $res1 && $res2;
        }
        self::checkTrans($res);
        return $res;
    }

    /**
     * 返回下单红包
     * @param $orderInfo
     * @return bool
     */
    public static function backOrderEnvelope($orderInfo){
        $brokerageRatio = (SystemConfigService::get('store_brokerage_envelope_ratio') ?: 0)/100;
        if($brokerageRatio <= 0) return true;
        $brokeragePrice = bcmul($orderInfo['pay_price'],$brokerageRatio,2);
        if($brokeragePrice <= 0) return true;
        $mark = '成功消费'.floatval($orderInfo['pay_price']).'元,奖励红包'.floatval($brokeragePrice);
        self::beginTrans();
        $res = StoreEnvelopeUser::addUserEnvelope($orderInfo['uid'],$orderInfo['id'],$brokeragePrice,2,'下单红包',$mark);
        self::checkTrans($res);
        return $res;
    }

    /**
     * 直推奖（定时任务）
     * @return bool
     */
    public static function backPushBrokerage(){
        $user_ids = User::where('user_identity',0)->column('uid');
        if(!$user_ids) return true;
        $num = (int)SystemConfigService::get('store_brokerage_push_num');
        $price = (int)SystemConfigService::get('store_brokerage_push_price');
        $num_two = (int)SystemConfigService::get('store_brokerage_push_num_two');
        $price_two = (int)SystemConfigService::get('store_brokerage_push_price_two');
        $num_three = (int)SystemConfigService::get('store_brokerage_push_num_three');
        $price_three = (int)SystemConfigService::get('store_brokerage_push_price_three');
        $brokerageRatio = 0;
        foreach ($user_ids as $k => $val){
            $uids = User::where('spread_uid',$val)->whereTime('add_time','last month')->column('uid');
            $count = count($uids);
            if($count < $num) continue;
            if($count>=$num_three){//第三等级
                if(!self::test($uids,$price_three)) continue;
                $brokerageRatio = (SystemConfigService::get('store_brokerage_push_ratio_three') ?: 0)/100;
            }elseif($count>=$num_two&&$count<$num_three){//第二等级
                if(!self::test($uids,$price_two)) continue;
                $brokerageRatio = (SystemConfigService::get('store_brokerage_push_ratio_two') ?: 0)/100;
            }elseif($count>=$num&&$count<$num_two){//第一等级
                if(!self::test($uids,$price)) continue;
                $brokerageRatio = (SystemConfigService::get('store_brokerage_push_ratio') ?: 0)/100;
            }
            $money=UserBill::where('uid',$val)->where('category','now_money')->where('type','brokerage')->where('pm',1)->where('status',1)->whereTime('add_time', 'last month')->column('number');
            $sum= array_sum($money);
            $brokeragePrice = bcmul($sum,$brokerageRatio,2);
            if($brokeragePrice <= 0) continue;
            $mark = '成功消费'.floatval($sum).'元,奖励直推佣金'.floatval($brokeragePrice);
            self::beginTrans();
            $res1 = UserBill::income('获得直推佣金',$val,'now_money','brokerage',$brokeragePrice,0,0,$mark,1,2);
            $res2 = self::bcInc($val,'now_money',$brokeragePrice,'uid');
            $res = $res1 && $res2;
            self::checkTrans($res);
        }
        return true;
    }

    public static function test($uids,$money){
        foreach ($uids as $k =>$val){
            $total_money = StoreOrder::where('o.uid',$val)->alias('o')->join('store_order_status sos','sos.oid=o.id')->where('change_type','user_take_delivery')
                ->whereTime('sos.change_time','last month')->whereIn('o.status',[2,3,4])->sum('o.pay_price');
            if($money>$total_money)
                return false;
        }
        return true;
    }

    /**
     * 获取我的团队
     * @param $pid
     * @param $type
     * @param int $first
     * @param int $limit
     * @return array
     */
    public static function getSpreadList($pid,$type,$first = 0,$limit = 20){
        $list = self::getSpreadTree([$pid],$type);
        $count = count($list);
        if(empty($count))
            return ['list'=>$list,'count'=>$count];
        many_array_sort($list,'add_time');
        $list = array_slice($list,$first*$limit,$limit);
        foreach ($list as $k => $val){
            $list[$k]['add_time'] = date('Y-m-d',$val['add_time']);
            $list[$k]['order_price'] = StoreOrder::getUserPrice($val['uid']);
            $userInfo = User::get(['uid'=>$val['uid']]);
            $list[$k]['nickname'] = isset($userInfo['nickname'])?$userInfo['nickname']:'';
            $list[$k]['avatar'] = isset($userInfo['avatar'])?$userInfo['avatar']:'';
            $list[$k]['commission'] = 0;
            $order_ids = StoreOrder::where('uid',$val['uid'])->whereIn('status',[2,3])->column('id');
            if(!empty($order_ids)) {
                $now_money = UserBill::where('uid', $val['spread_uid'])->where('category', 'now_money')->whereIn('link_id', $order_ids)->sum('number');
                $list[$k]['commission'] = empty($now_money)?0:$now_money;
            }
        }
        return ['list'=>$list,'count'=>$count];
    }

    /**
     * 获取关系链树
     * @param $pid
     * @param int $level
     * @param int $cos
     * @return array
     */
    public static function getSpreadTree($pid,$level=0,&$cos=1){
        $list = self::whereIn('spread_uid',$pid)->field("uid,nickname,avatar,add_time,{$cos} as level,spread_uid")->order('add_time DESC')->select()->toArray()?:[];
        if(empty($list))
            return $list;
        $spread_uids = array_column($list,'uid');
        if($level==0) {
            if ($cos < 3) {
                $cos++;
                $list1 = self::getSpreadTree($spread_uids,$level,$cos);
                if(!empty($list1))
                    $list = array_merge($list,$list1);
            }
        }
        $i = $cos;
        if($level==2) {
            if ($cos < 3) {
                $cos++;
                $i++;
                $list1 = self::getSpreadTree($spread_uids,$level,$cos);
                if(!empty($list1)&&$i!=2) {
                    $list = array_merge($list, $list1);
                }elseif(!empty($list1)&&$i==2){
                    $list = $list1;
                }elseif(empty($list1)&&$i==2){
                    $list = [];
                }
            }
        }
        return $list;
    }
}