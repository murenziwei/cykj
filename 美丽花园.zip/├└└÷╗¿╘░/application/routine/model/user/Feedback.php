<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\14 0014
 * Time: 22:46
 */

namespace app\routine\model\user;

use basic\ModelBasic;
use traits\ModelTrait;

class Feedback extends ModelBasic
{
    use ModelTrait;

    public function setParamsAttr($value){
        return htmlspecialchars_decode($value);
    }

    public function getParamsAttr($value){
        return json_decode($value,true)?:[];
    }
}