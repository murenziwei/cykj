<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\8 0008
 * Time: 15:28
 */

namespace app\routine\model\topic;


use basic\ModelBasic;
use behavior\topic\TopicBehavior;
use service\HookService;
use traits\ModelTrait;

class TopicRelation extends ModelBasic
{
    use ModelTrait;
    /**
     * 获取用户点赞所有产品的个数
     * @param $uid
     * @return int|string
     */
    public static function getUserIdLike($uid = 0,$is_today=false){
        $model = new self();
        if($is_today)
            $model->whereTime('add_time','today');
        $count = $model->where('uid',$uid)->where('type','like')->count();
        return $count;
    }

    /**
     * 获取用户收藏所有产品的个数
     * @param $uid
     * @return int|string
     */
    public static function getUserIdCollect($uid = 0){
        $count = self::where('uid',$uid)->where('type','collect')->count();
        return $count;
    }

    /**
     * 获取用户分享数量
     * @param int $uid
     * @param bool $type
     * @return int|string
     */
    public static function getUserShare($uid=0,$type=false){
        $model = self::where('uid',$uid)->where('type','share');
        if($type)
            $model->whereTime('add_time','today');
        $count = $model->count();
        return $count;
    }

    /**
     * 添加点赞 收藏、分享
     * @param $productId
     * @param $uid
     * @param $relationType
     * @param string $category
     * @return bool
     */
    public static function topicRelation($topic_Id,$uid,$relationType,$category = 'storeTopic')
    {
        if(!$topic_Id) return self::setErrorInfo('帖子不存在!');
        $relationType = strtolower($relationType);
        $category = strtolower($category);
        $data = ['uid'=>$uid,'topic_id'=>$topic_Id,'type'=>$relationType,'category'=>$category];
        if(self::be($data)) return true;
        $data['add_time'] = time();
        self::set($data);
        HookService::afterListen('topic_'.$relationType,$topic_Id,$category,false,TopicBehavior::class);
        return true;
    }

    /**
     * 批量 添加点赞 收藏
     * @param $productIdS
     * @param $uid
     * @param $relationType
     * @param string $category
     * @return bool
     */
    public static function topicRelationAll($topicIdS,$uid,$relationType,$category = 'storeTopic'){
        $res = true;
        if(is_array($topicIdS)){
            self::beginTrans();
            foreach ($topicIdS as $topicId){
                $res = $res && self::topicRelation($topicId,$uid,$relationType,$category);
            }
            self::checkTrans($res);
            return $res;
        }
        return $res;
    }

    /**
     * 取消 点赞 收藏
     * @param $productId
     * @param $uid
     * @param $relationType
     * @param string $category
     * @return bool
     */
    public static function unTopicRelation($topicId,$uid,$relationType,$category = 'storeTopic')
    {
        if(!$topicId) return self::setErrorInfo('帖子不存在!');
        $relationType = strtolower($relationType);
        $category = strtolower($category);
        self::where(['uid'=>$uid,'topic_id'=>$topicId,'type'=>$relationType,'category'=>$category])->delete();
        HookService::afterListen('topic_un_'.$relationType,$topicId,$uid,false,TopicBehavior::class);
        return true;
    }

    /**
     * 获取点赞、收藏数量
     * @param $topicId
     * @param $relationType
     * @param string $category
     * @return int|string
     */
    public static function topicRelationNum($topicId,$relationType,$category = 'storeTopic')
    {
        $relationType = strtolower($relationType);
        $category = strtolower($category);
        return self::where('type',$relationType)->where('topic_id',$topicId)->where('category',$category)->count();
    }

    /**
     * 获取是否收藏、点赞
     * @param $topic_id
     * @param $uid
     * @param $relationType
     * @param string $category
     * @return bool
     */
    public static function isTopicRelation($topic_id,$uid,$relationType,$category = 'storeTopic')
    {
        $type = strtolower($relationType);
        $category = strtolower($category);
        return self::be(compact('topic_id','uid','type','category'));
    }
}