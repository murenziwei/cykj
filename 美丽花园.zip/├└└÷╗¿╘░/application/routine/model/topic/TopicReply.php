<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\8 0008
 * Time: 17:53
 */

namespace app\routine\model\topic;


use basic\ModelBasic;
use traits\ModelTrait;

class TopicReply extends ModelBasic
{
    use ModelTrait;

    protected $insert = ['add_time'];

    protected function setAddTimeAttr()
    {
        return time();
    }
}