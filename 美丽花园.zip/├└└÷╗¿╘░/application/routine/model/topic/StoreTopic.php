<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\8 0008
 * Time: 17:52
 */

namespace app\routine\model\topic;

use basic\ModelBasic;
use traits\ModelTrait;

class StoreTopic extends ModelBasic
{
    use ModelTrait;

    public function getParamsAttr($value){
        return json_decode($value,true)?:[];
    }

    public function getContentAttr($value){
        return json_decode($value,true)?:[];
    }

    /**
     * 获取一条新闻
     * @param int $id
     * @return array|false|\PDOStatement|string|\think\Model
     */
    public static function getTopicOne($id = 0){
        if(!$id) return [];
        $list = self::where('status',1)->where('is_del',0)->where('tid',$id)->order('sort desc,tid desc')->find();
        if($list){
            $list = $list->toArray();
            return $list;
        }
        else return [];
    }

    /**
     * 获取某个分类底下的文章
     * @param $cid
     * @param $first
     * @param $limit
     * @param string $field
     * @return mixed
     */
    public static function cidByTopicList($cid, $first, $limit, $field = '*',$search='')
    {
        $model = new self();
//        if ($cid) $model->where("CONCAT(',',cid,',')" ,'LIKE'," '%,$cid,%'");
        if ($cid) $model->where('cate_id',$cid);
        $model = $model->field($field);
        $model = $model->where('status', 1);
        if(!empty($search))
            $model = $model->whereLike('title',"%{$search}%");
        $model = $model->where('is_del', 0);
        $model = $model->order('sort DESC,add_time DESC');
        if($limit)  $model = $model->limit($first, $limit);
        return $model->select();
    }
}