<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/5
 * Time: 12:08
 */

namespace app\routine\model\store;


use app\routine\model\user\User;
use basic\ModelBasic;
use traits\ModelTrait;

class StoreEnvelopeUser extends ModelBasic
{
    use ModelTrait;

    /**
     * @param string $prefix
     * @return $this
     */
    public static function validWhere($prefix = '')
    {
        $model = new self;
        if($prefix){
            $model->alias($prefix);
            $prefix .= '.';
        }
        return $model->where("{$prefix}status",1)->where("{$prefix}is_del",0);
    }


    public static function issueUserEnvelope($id,$uid)
    {
        $issueEnvelopeInfo = StoreEnvelopeUser::get(['uid'=>$uid,'id'=>$id]);
        if(!$issueEnvelopeInfo||$issueEnvelopeInfo['status']==2) return self::setErrorInfo('领取的红包已领完或已过期!');
        if($issueEnvelopeInfo['status']==1)
            return self::setErrorInfo('已领取过该红包!');
        self::beginTrans();
        $res1 = false != self::edit(['status'=>1],$id,'id');
        $res2 = User::bcInc($issueEnvelopeInfo['uid'],'red_envelope',$issueEnvelopeInfo['envelope_price'],'uid');

        $res = $res1 && $res2;
        self::checkTrans($res);
        return $res;
    }

    /**
     * 发送新用户待领取红包
     * @return bool
     */
    public static function sendUserEnvelope(){
        $envelopeInfo = StoreEnvelope::where('status',1)->where(['is_del'=>0])->where('type',1)->find();
        if(!$envelopeInfo)
            return true;
        $envelopeUids = self::where('eid',$envelopeInfo['id'])->where('type',1)->column('uid');
        $model = User::where('status',1);
        if(!empty($envelopeUids))
            $model->whereNotIn('uid',$envelopeUids);
        $uids = $model->column('uid');
        if(empty($uids))
            return true;
        foreach($uids as $k => $val) {
            self::addUserEnvelope($val,$envelopeInfo['id'],$envelopeInfo['envelope_price'],1,$envelopeInfo['title']);
        }
    }

    /**
     * 添加待领取红包
     * @param $uid
     * @param $eid
     * @param $price
     * @param int $type
     * @param string $title
     * @param string $mark
     * @return object
     */
    public static function addUserEnvelope($uid,$eid,$price,$type = 1,$title='新用户红包',$mark='新用户红包')
    {
        $data = [];
        $data['eid'] = $eid;
        $data['uid'] = $uid;
        $data['envelope_title'] = $title;
        $data['envelope_price'] = $price;
        $data['add_time'] = time();
        $data['type'] = $type;
        $data['is_fail'] = 1;
        $data['status'] = 0;
        $data['mark'] = $mark;
        return self::set($data);
    }
}