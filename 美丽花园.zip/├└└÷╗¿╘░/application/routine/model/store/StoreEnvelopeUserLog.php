<?php
/**
 * Created by PhpStorm.
 * User: D.Chen
 * Email: 571543900@qq.com
 * Date: 2019/3/5
 * Time: 16:45
 */

namespace app\routine\model\store;


use basic\ModelBasic;
use traits\ModelTrait;

class StoreEnvelopeUserLog extends ModelBasic
{
    use ModelTrait;

    /**
     * 添加红包使用记录
     * @param $orderInfo
     * @return object
     */
    public static function addUserEnvelopeLog($orderInfo)
    {
        $mark = '成功消费'.floatval($orderInfo['pay_price']).'元,抵扣了'.floatval($orderInfo['deduction_price']).'元红包';
        $data = [];
        $data['eid'] = $orderInfo['id'];
        $data['uid'] = $orderInfo['uid'];
        $data['envelope_price'] = $orderInfo['deduction_price'];
        $data['add_time'] = time();
        $data['type'] = 2;
        $data['is_fail'] = 1;
        $data['status'] = 1;
        $data['mark'] = $mark;
        return self::set($data);
    }

}