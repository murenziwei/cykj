<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019\3\11 0011
 * Time: 16:56
 */

namespace app\routine\model\store;


use basic\ModelBasic;
use traits\ModelTrait;

class ShareLog extends ModelBasic
{
    use ModelTrait;

    /**
     * 添加记录
     * @param $uid
     * @param $type
     * @param $link_id
     * @return object
     */
    public static function addShareLog($uid,$category,$link_id){
        $add_time = time();
        return self::set(compact('uid','category','link_id','add_time'));
    }

    public static function getUserIdShare($uid,$category,$is_today=false){
        $model = new self();
        if($is_today)
            $model->whereTime('add_time','today');
        return $model->where('uid',$uid)->where('category',$category)->group('link_id')->count();
    }
}