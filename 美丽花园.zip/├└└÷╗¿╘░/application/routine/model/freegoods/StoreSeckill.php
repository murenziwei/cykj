<?php
namespace app\routine\model\freegoods;

use think\Db;
use traits\ModelTrait;
use basic\ModelBasic;

/**
 * Class Article
 * @package app\routine\model\article
 */
class StoreSeckill extends ModelBasic{
    use ModelTrait;
    public static function goodsList($page = 1,$offset = 10){

        $limit = ($page-1)*$offset;
        $model = new self();
        $model = $model->where('status',1);
        //$model = $model->order('start_time DESC');
        $model = $model->limit($limit,$offset);

        return $model->select()->toArray();

    }
    public static function confirm($id){
        $model = new self();
        $model = $model->where('id',$id);

        return $model = $model->find()->toArray();
    }



}