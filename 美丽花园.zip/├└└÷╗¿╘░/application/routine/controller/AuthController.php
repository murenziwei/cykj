<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/12/11
 */

namespace app\routine\controller;

use app\routine\model\store\StoreEnvelopeUser;
use app\routine\model\user\User;
use app\routine\model\user\WechatUser;
use service\JsonService;
use think\Controller;
use think\Request;
use app\admin\model\system\SystemConfig;
use app\routine\model\routine\RoutineServer;

class AuthController extends Controller
{
    protected $uid = 0;
    protected $userInfo = [];
    protected function _initialize()
    {
        parent::_initialize();

//        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) {
            if(!empty(input('openid'))){
                $uid = WechatUser::openidTouid(input('openid'));
                $userInfo = User::get($uid);
            }else{
                $uid = Request::instance()->get('uid',0);
                if(!$uid)
                    $uid = Request::instance()->post('uid',0);
                $userInfo = User::get($uid);
            }
            if($userInfo) $userInfo->toArray();
            else return JsonService::fail('没有获取用户UID');
            $this->userInfo = $userInfo;//根据uid获取用户信息

            StoreEnvelopeUser::sendUserEnvelope();
            WechatUser::checkTime();
//        } else {
//            echo "非法访问";exit;
//        }


    }
    /**
     * 根据前台传code  获取 openid 和  session_key //会话密匙
     * @param string $code
     * @return array|mixed
     */
    public function setCode($code = ''){
        if($code == '') return [];
        $routineAppId = SystemConfig::getValue('routine_appId');//小程序appID
        $routineAppSecret = SystemConfig::getValue('routine_appsecret');//小程序AppSecret
        $url = 'https://api.weixin.qq.com/sns/jscode2session?appid='.$routineAppId.'&secret='.$routineAppSecret.'&js_code='.$code.'&grant_type=authorization_code';
        return json_decode(RoutineServer::curlGet($url),true);
    }
}