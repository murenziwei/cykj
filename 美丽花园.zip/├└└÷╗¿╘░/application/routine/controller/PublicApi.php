<?php
namespace app\routine\controller;

/**
 * 小程序公共接口
 * Class PublicApi
 * @package app\routine\controller
 *
 */
class PublicApi extends Controller{


}