<?php
namespace app\routine\controller;

use Api\Express;
use app\routine\model\routine\RoutineCode;
use app\routine\model\routine\RoutineFormId;
use app\routine\model\routine\RoutineTemplate;
use app\routine\model\store\StoreCategoryIndex;
use app\routine\model\store\StoreCombination;
use app\routine\model\store\StoreEnvelope;
use app\routine\model\store\StoreEnvelopeUser;
use app\routine\model\store\StoreEnvelopeUserLog;
use app\routine\model\store\StoreOrderStatus;
use app\routine\model\topic\Topic as TopicModel;
use app\routine\model\topic\StoreTopic as StoreTopicModel;
use app\routine\model\topic\Topic;
use app\routine\model\topic\TopicCategory;
use app\routine\model\topic\TopicRelation;
use app\routine\model\topic\TopicReply;
use service\JsonService;
use service\GroupDataService;
use service\RoutineBizDataCrypt;
use service\SystemConfigService;
use service\UploadService;
use service\UtilService;
use think\Request;
use service\WechatTemplateService;
use service\CacheService;
use service\HookService;
use behavior\StoreProductBehavior;
use think\Url;
use app\routine\model\store\StoreCouponUser;
use app\routine\model\store\StoreOrder;
use app\routine\model\store\StoreProductRelation;
use app\routine\model\store\StoreProductAttr;
use app\routine\model\store\StoreProductAttrValue;
use app\routine\model\store\StoreProductReply;
use app\routine\model\store\StoreCart;
use app\routine\model\store\StoreCategory;
use app\routine\model\store\StoreProduct;
use app\routine\model\store\StoreSeckill;
use app\routine\model\user\User;
use app\routine\model\user\UserNotice;
use app\routine\model\store\StoreCouponIssue;
use app\routine\model\store\StoreCouponIssueUser;
use app\routine\model\store\StoreOrderCartInfo;
use app\routine\model\store\StorePink;
use app\routine\model\store\StoreService;
use app\routine\model\store\StoreServiceLog;
use app\routine\model\user\UserAddress;
use app\routine\model\user\UserBill;
use app\routine\model\user\UserExtract;
use app\routine\model\user\UserRecharge;
use app\routine\model\user\UserSign;
use app\routine\model\user\WechatUser;
use app\admin\model\system\SystemConfig;
use app\routine\model\store\StoreBargain;
use app\routine\model\store\StoreBargainUser;
use app\routine\model\store\StoreBargainUserHelp;
use app\routine\model\article\Article as ArticleModel;
use app\routine\model\store\StoreCategory as CategoryModel;
use app\routine\model\freegoods\StoreSeckill as StoreSeckillModel;


/**
 * 小程序接口
 * Class AuthApi
 * @package app\routine\controller
 *
 */
class FreeGoods extends AuthController{

   public function goods_list($page){

       $data = StoreSeckillModel::goodsList($page);

       return JsonService::successful($data);
   }
    public static function goods_confirm($id)
    {

        if ($id) {
            $data = StoreSeckillModel::confirm($id);
            if ($data['stock'] <= 0) {
                return JsonService::fail('库存不足,请联系客服人员');
            }
        }else{
            return JsonService::fail('参数错误,请联系客服人员');
        }
        return JsonService::successful();
    }
    public function getOrderMessage($id){

        $data = StoreSeckillModel::confirm($id);

        return JsonService::successful($data);
    }
    public function check_skec ($uid,$id)
    {
        if($id){
            $data = StoreOrder::checkSeckill($uid,$id);
            return JsonService::successful($data);
        }

    }
}