<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/11/11
 */

namespace app\admin\model\user;

use app\admin\model\wechat\WechatUser;
use traits\ModelTrait;
use basic\ModelBasic;

/**
 * 用户通知查看 model
 * Class UserNoticeSee
 * @package app\admin\model\user
 */
class UserNoticeSee extends ModelBasic
{
    use ModelTrait;
}