<?php /** * * @author: xaboy<365615158@qq.com> * @day: 2017/11/02 */
namespace app\routine\model\article;

use traits\ModelTrait;
use basic\ModelBasic;


/**
 * Class ArticleCategory
 * @package app\routine\model\article
 */
class ArticleCategory extends ModelBasic
{
    use ModelTrait;

}