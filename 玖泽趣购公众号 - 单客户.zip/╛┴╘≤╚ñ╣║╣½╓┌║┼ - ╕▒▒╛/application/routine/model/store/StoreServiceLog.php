<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/12/23
 */

namespace app\routine\model\store;


use basic\ModelBasic;
use traits\ModelTrait;

class StoreServiceLog extends ModelBasic
{
    use ModelTrait;
}