<?php
/**
 *
 * @author: xaboy<365615158@qq.com>
 * @day: 2017/12/19
 */

namespace behavior\wap;

class WapBehavior
{
    public static function wapInit()
    {
    }
    
}